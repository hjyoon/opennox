"""Build/archive/run two isolated native instruction observations; no game calls."""
from pathlib import Path
import datetime,hashlib,json,os,platform,re,signal,subprocess,sys,zipfile

D=Path(__file__).resolve().parent
SRC=D/'native-word-store-fault-control-drafts-v1'
O=D/'native-word-store-control-local-v1'
R=Path('/Users/ghost/codex-sandbox/worktrees/opennox-r344-20261020')
sha=lambda b:hashlib.sha256(b).hexdigest()
def ident(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def save(name,x):
    p=O/name
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
    return ident(p)
assert platform.system()=='Darwin' and platform.machine()=='arm64'
O.mkdir(exist_ok=False)
manifest=SRC/'native-word-store-control-source-manifest-v1.json'
assert ident(manifest)['sha256']=='f7f5de18b5e01d88ab080be7f10f279ee1521632734c818bfb2334a871eacaf1'
m=json.loads(manifest.read_bytes())
for want in list(m['files'].values())+list(m['read_only_SDK_field_accessor_bindings'].values()):
    got=ident(Path(want['path']));assert got==want
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
sdk=subprocess.check_output(['/usr/bin/xcrun','--sdk','macosx','--show-sdk-path'],text=True).strip()
compiler=subprocess.check_output(['/usr/bin/clang','--version'],text=True)
binary=O/'native-word-store-arm64-v1'
command=['/usr/bin/clang','-arch','arm64','-isysroot',sdk,'-std=c11','-O2','-g0','-Wall','-Wextra','-Werror',
         '-fno-builtin','-fno-stack-protector',str(SRC/'native_word_store_fault_control_v1.c'),'-o',str(binary)]
intent=save('compile-input-and-intent-v1.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    command=command,compiler_version=compiler,SDK=sdk,SDK_realpath=str(Path(sdk).resolve()),
    source_manifest=ident(manifest),source_files=m['files'],SDK_accessor_bindings=m['read_only_SDK_field_accessor_bindings'],
    supervisor=ident(Path(__file__)),preexec_wrapper=ident(D/'native-word-store-preexec-v1.py'),
    original_or_Go_or_game_calls=0,CI=False))
with (O/'compile.stdout.log').open('xb') as out,(O/'compile.stderr.log').open('xb') as err:
    build=subprocess.run(command,cwd=O,stdout=out,stderr=err,timeout=30)
save('compile-exit-v1.json',dict(returncode=build.returncode,stdout=ident(O/'compile.stdout.log'),stderr=ident(O/'compile.stderr.log')))
assert build.returncode==0
disasm=subprocess.check_output(['/usr/bin/otool','-arch','arm64','-tvV',str(binary)],text=True)
(O/'actual-binary-disassembly-v1.txt').write_text(disasm)
arch=subprocess.check_output(['/usr/bin/file',str(binary)],text=True)
(O/'actual-binary-architecture-v1.txt').write_text(arch)
assert 'Mach-O 64-bit executable arm64' in arch
lines=disasm.splitlines();start=lines.index('_opennox_atomicity_store16_v1:')+1;body=[]
for line in lines[start:]:
    if re.fullmatch(r'\S+:',line):break
    body.append(line)
store=[line for line in body if re.search(r'\bstrh\b',line)]
assert len(store)==1 and not any(re.search(r'\bstrb\b',line)for line in body)
store_line=store[0];store_va=int(store_line.split()[0],16)
function_va=int(next(line for line in body if re.match(r'^[0-9a-fA-F]{16}\s',line)).split()[0],16)
store_offset=store_va-function_va
save('actual-STRH-before-first-exec-v1.json',dict(binary=ident(binary),function_body=body,
    store_instruction=store_line,store_offset_from_runtime_function=store_offset,
    compiler_and_source=intent,whole_disassembly=ident(O/'actual-binary-disassembly-v1.txt')))
archive=O/'native-word-store-actual-executable-PREEXEC-v1.zip'
files=[binary,SRC/'native_word_store_fault_control_v1.c',SRC/'cases-v1.json',manifest,
       D/'native-word-store-preexec-v1.py',Path(__file__),O/'compile-input-and-intent-v1.json',
       O/'compile.stdout.log',O/'compile.stderr.log',O/'compile-exit-v1.json',
       O/'actual-binary-disassembly-v1.txt',O/'actual-binary-architecture-v1.txt',O/'actual-STRH-before-first-exec-v1.json']
members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:
        member='product/'+p.name if p==binary else 'evidence/'+p.name
        assert member not in members;z.writestr(member,p.read_bytes());members[member]=ident(p)
with zipfile.ZipFile(archive) as z:
    for member,want in members.items():
        data=z.read(member);assert len(data)==want['bytes']and sha(data)==want['sha256']
save('actual-executable-PREEXEC-archive-byteverified-v1.json',dict(archive=ident(archive),members=members,all_members_byte_equal=True))
results=[]
for case in ['healthy-two-byte','guarded-last-byte']:
    with zipfile.ZipFile(archive) as z:assert z.read('product/'+binary.name)==binary.read_bytes()
    preexec=O/(case+'-PREEXEC.json');cmd=[sys.executable,str(D/'native-word-store-preexec-v1.py'),str(binary),ident(binary)['sha256'],str(preexec),case]
    save(case+'-intent-v1.json',dict(command=cmd,actual_binary=ident(binary),preexecution_archive=ident(archive),timeout_seconds=15))
    out,err=O/(case+'.stdout.log'),O/(case+'.stderr.log')
    with out.open('xb') as fo,err.open('xb') as fe:
        child=subprocess.Popen(cmd,cwd=O,stdout=fo,stderr=fe);forced=False
        try:code=child.wait(timeout=15)
        except subprocess.TimeoutExpired:forced=True;child.kill();code=child.wait()
    result=dict(case=case,pid=child.pid,returncode=code,forced=forced,stdout=ident(out),stderr=ident(err),preexec=ident(preexec) if preexec.exists()else None)
    save(case+'-exit-v1.json',result);results.append(result)
    assert not forced and preexec.exists()
    pre=json.loads(preexec.read_bytes());rows=[json.loads(line)for line in out.read_text().splitlines()]
    assert pre['pid']==child.pid and pre['sha256']==ident(binary)['sha256']
    assert len(rows)==2 and rows[0]['event']=='before-store'and rows[0]['pid']==child.pid and rows[0]['case']==case
    before,after=rows
    assert int(before['store_address'],16)>0xffffffff and int(before['guard_page'],16)-int(before['store_address'],16)==before['accessible_store_bytes']
    if case=='healthy-two-byte':
        assert code==0 and after['event']=='healthy-store-returned'and(after['after_first_hex'],after['after_second_hex'])==('02','00')
    else:
        assert after['event']=='signal-observation'and after['pid']==child.pid and after['case']==case and after['armed']==1
        assert after['signal']in(signal.SIGBUS,signal.SIGSEGV)and code==after['handler_exit_code']==160+after['signal']
        assert int(after['fault_pc'],16)==int(after['store_function'],16)+store_offset
        assert all(after[k]==before[k]for k in ['store_function','store_address','guard_page','page_bytes','store_width_bytes','store_value_hex','before_first_hex'])
        result['observed_after_fault_first_hex']=after['after_first_hex']
        result['signal_was_handled_then_explicit_exit']=True
    result['raw_records']=rows
for want in m['files'].values():assert ident(Path(want['path']))==want
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
receipt=save('native-ARM64-word-store-observations-qualified-v1.json',dict(
    source_manifest=ident(manifest),compiler_intent=intent,executable_archive=ident(archive),binary=ident(binary),
    actual_store_instruction=store_line,store_offset=store_offset,cases=results,
    fault_byte_observed_without_expected_atomicity=True,original_expected_files_changed=False,
    original_or_parent_or_Go_or_game_calls=0,physical_native_PE_equivalence_qualified=False,overall100=False))
# The exact executed bytes remain in the verified canonical PREEXEC archive.
with zipfile.ZipFile(archive) as z:assert z.read('product/'+binary.name)==binary.read_bytes()
removed=ident(binary);binary.unlink()
save('owned-executable-duplicate-cleanup-v1.json',dict(removed=removed,archive=ident(archive),all_bytes_equal_before_unlink=True))
print(json.dumps(receipt))
