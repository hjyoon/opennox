from pathlib import Path
import hashlib,json,os,sys

binary,expected,record,case=sys.argv[1:]
data=Path(binary).read_bytes()
assert hashlib.sha256(data).hexdigest()==expected
payload=dict(pid=os.getpid(),binary=binary,bytes=len(data),sha256=expected,
             argv=[binary,'--case',case],before_exec=True)
with Path(record).open('x') as f:
    json.dump(payload,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
os.execv(binary,[binary,'--case',case])
