"""Supervise one frozen local original-only recording; no source edits or CI."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys, time

D=Path(__file__).resolve().parent
R=Path('/Users/ghost/codex-sandbox/worktrees/opennox-r344-20261020')
PY=Path('/Users/ghost/codex-sandbox/cache/opennox-native-oracle-py312-v1/bin/python')
SEAL=D/'root-approved-parent-input-source-seal-v2.json'
OUT=D/'original-recording-first-v2'
sha=lambda b:hashlib.sha256(b).hexdigest()
def identity(p):
    b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=sha(b))
def save(name,obj):
    p=D/name
    with p.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
    return identity(p)
seal=json.loads(SEAL.read_bytes())
for key in ['producer','generator','services','original_EXE','unchanged_main_manifest','dedicated_manifest','inputs']:
    want=seal[key];got=identity(Path(want['path']))
    assert all(got[k]==want[k] for k in ['path','bytes','sha256']),key
assert not OUT.exists()
assert subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
command=[str(PY),seal['producer']['path'],'--input-seal',str(SEAL),'--out',str(OUT),'--execute-reviewed-original']
intent=save('first-original-local-recording-intent-v3.json',dict(
    utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,cwd=str(D),
    supervisor=identity(Path(__file__)),input_seal=identity(SEAL),
    requested_cases=seal['inputs']['count'],requested_original_root_calls=2*seal['inputs']['count'],
    timeout_seconds=900,no_Go_build_test_game=True,CI=False))
stdout,stderr=D/'first-original-local-recording-v3.stdout.log',D/'first-original-local-recording-v3.stderr.log'
assert not stdout.exists() and not stderr.exists()
started=time.monotonic();forced=False
with stdout.open('xb') as fo,stderr.open('xb') as fe:
    child=subprocess.Popen(command,cwd=D,stdout=fo,stderr=fe)
    with (D/'first-original-local-recording-v3.heartbeat.jsonl').open('x') as heartbeat:
        while child.poll() is None:
            if time.monotonic()-started>900:
                forced=True;child.kill();break
            row=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=child.pid,
                     elapsed_seconds=round(time.monotonic()-started,3),running=True)
            heartbeat.write(json.dumps(row)+'\n');heartbeat.flush()
            print(json.dumps(row),flush=True)
            time.sleep(5)
    code=child.wait()
post={}
source_error=None
try:
    for key in ['producer','generator','services','original_EXE','unchanged_main_manifest','dedicated_manifest','inputs']:
        want=seal[key];got=identity(Path(want['path']))
        assert all(got[k]==want[k] for k in ['path','bytes','sha256']),key
        post[key]=got
    prior=json.loads(Path(seal['all_prior_8681_tracked_source_seal']['path']).read_bytes())
    for path,want in prior['tracked_files'].items():
        got=identity(R/path)
        assert dict(bytes=got['bytes'],sha256=got['sha256'])==want,path
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=R)
except Exception as exc:
    source_error=dict(type=type(exc).__name__,message=str(exc))
proof=OUT/'actual-original-parent-recorder-proof-v2.json'
receipt=save('first-original-local-recording-exit-v3.json',dict(
    intent=intent,pid=child.pid,returncode=code,forced=forced,
    elapsed_seconds=round(time.monotonic()-started,3),stdout=identity(stdout),stderr=identity(stderr),
    producer_proof=identity(proof) if proof.exists() else None,postexecution_source_bindings=post,
    all_prior8681_exact=source_error is None,source_error=source_error,
    independent_result_qualification_pending=True,CI=False,overall100=False))
print(json.dumps(receipt),flush=True)
sys.exit(code if code else 1 if forced or source_error else 0)
