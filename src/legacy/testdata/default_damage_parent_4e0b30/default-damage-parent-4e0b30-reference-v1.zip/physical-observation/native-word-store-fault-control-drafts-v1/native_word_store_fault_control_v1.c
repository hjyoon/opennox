// Standalone native ARM64 observation only. No Go runtime or OpenNox symbols.
// Compile/run is a root-controlled later action; this source makes no claim
// about the unchanged original records or native/PE physical equivalence.
#define _DARWIN_C_SOURCE 1
#include <errno.h>
#include <inttypes.h>
#include <mach/arm/thread_status.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/ucontext.h>
#include <unistd.h>

#if !defined(__APPLE__) || (!defined(__aarch64__) && !defined(__arm64__))
#error "This independent observation requires native Darwin ARM64"
#endif
#if __BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__
#error "The declared 0002 store case requires little endian"
#endif
_Static_assert(sizeof(uint16_t) == 2, "word width");

static volatile unsigned char *g_first;
static uintptr_t g_guard;
static uintptr_t g_store_function;
static size_t g_page_size;
static pid_t g_pid;
static const char *g_case;
static volatile sig_atomic_t g_armed;

// One actual 16-bit ARM64 store. The later binary/PC/disassembly proof must
// verify this STRH; do not replace it with two byte stores or simulated writes.
__attribute__((noinline, used))
void opennox_atomicity_store16_v1(void *address, uint16_t value) {
    __asm__ volatile("strh %w[value], [%[address]]"
                     :
                     : [value] "r" ((uint32_t)value), [address] "r" (address)
                     : "memory");
}

// Handler formatting uses bounded local byte writes only; no stdio, malloc,
// locks, mmap/mprotect, target writes, signal reinstallation or Go machinery.
static void append_text(char *buffer, size_t cap, size_t *n, const char *text) {
    while (*text && *n < cap) buffer[(*n)++] = *text++;
}
static void append_u64(char *buffer, size_t cap, size_t *n, uint64_t value) {
    char digits[20];
    size_t count = 0;
    do { digits[count++] = (char)('0' + value % 10); value /= 10; } while (value);
    while (count && *n < cap) buffer[(*n)++] = digits[--count];
}
static void append_i64(char *buffer, size_t cap, size_t *n, int64_t value) {
    if (value < 0) { append_text(buffer, cap, n, "-"); value = -value; }
    append_u64(buffer, cap, n, (uint64_t)value);
}
static void append_hex64(char *buffer, size_t cap, size_t *n, uintptr_t value) {
    const char *digits = "0123456789abcdef";
    append_text(buffer, cap, n, "\"0x");
    for (int shift = (int)(8 * sizeof(value)) - 4; shift >= 0; shift -= 4) {
        if (*n < cap) buffer[(*n)++] = digits[(value >> shift) & 15];
    }
    append_text(buffer, cap, n, "\"");
}
static void append_byte(char *buffer, size_t cap, size_t *n, unsigned int value) {
    const char *digits = "0123456789abcdef";
    append_text(buffer, cap, n, "\"");
    if (*n < cap) buffer[(*n)++] = digits[(value >> 4) & 15];
    if (*n < cap) buffer[(*n)++] = digits[value & 15];
    append_text(buffer, cap, n, "\"");
}

static void observe_fault(int signo, siginfo_t *info, void *context) {
    char report[1024];
    size_t n = 0;
    const unsigned int first_after = g_first ? *g_first : 0;
    const ucontext_t *uc = (const ucontext_t *)context;
    const uintptr_t pc = uc && uc->uc_mcontext
        ? (uintptr_t)arm_thread_state64_get_pc(uc->uc_mcontext->__ss) : 0;
    const int status = 160 + signo;
    append_text(report, sizeof(report), &n,
        "{\"schema\":\"opennox-native-word-store-observation-v1\",\"event\":\"signal-observation\",\"case\":\"");
    append_text(report, sizeof(report), &n, g_case);
    append_text(report, sizeof(report), &n, "\",\"pid\":");
    append_i64(report, sizeof(report), &n, (int64_t)g_pid);
    append_text(report, sizeof(report), &n, ",\"armed\":");
    append_i64(report, sizeof(report), &n, (int64_t)g_armed);
    append_text(report, sizeof(report), &n, ",\"signal\":");
    append_i64(report, sizeof(report), &n, signo);
    append_text(report, sizeof(report), &n, ",\"si_code\":");
    append_i64(report, sizeof(report), &n, info ? info->si_code : 0);
    append_text(report, sizeof(report), &n, ",\"fault_address\":");
    append_hex64(report, sizeof(report), &n, info ? (uintptr_t)info->si_addr : 0);
    append_text(report, sizeof(report), &n, ",\"fault_pc\":");
    append_hex64(report, sizeof(report), &n, pc);
    append_text(report, sizeof(report), &n, ",\"store_function\":");
    append_hex64(report, sizeof(report), &n, g_store_function);
    append_text(report, sizeof(report), &n, ",\"store_address\":");
    append_hex64(report, sizeof(report), &n, (uintptr_t)g_first);
    append_text(report, sizeof(report), &n, ",\"guard_page\":");
    append_hex64(report, sizeof(report), &n, g_guard);
    append_text(report, sizeof(report), &n, ",\"page_bytes\":");
    append_u64(report, sizeof(report), &n, g_page_size);
    append_text(report, sizeof(report), &n,
        ",\"store_width_bytes\":2,\"store_value_hex\":\"0002\",\"before_first_hex\":\"aa\",\"after_first_hex\":");
    append_byte(report, sizeof(report), &n, first_after);
    append_text(report, sizeof(report), &n, ",\"handler_exit_code\":");
    append_i64(report, sizeof(report), &n, status);
    append_text(report, sizeof(report), &n,
        ",\"handler_target_access\":\"read-mapped-first-byte-only\",\"parent_calls\":0}\n");
    // A regular retained stdout file should accept this bounded record. If it
    // does not, root must retain the incomplete evidence and reject qualification.
    size_t sent = 0;
    while (sent < n) {
        ssize_t result = write(STDOUT_FILENO, report + sent, n - sent);
        if (result <= 0) break;
        sent += (size_t)result;
    }
    _exit(status); // handled-signal exit, never label it an unhandled signal
}

int main(int argc, char **argv) {
    if (argc != 3 || strcmp(argv[1], "--case") != 0 ||
        (strcmp(argv[2], "healthy-two-byte") != 0 && strcmp(argv[2], "guarded-last-byte") != 0)) {
        fprintf(stderr, "usage: %s --case healthy-two-byte|guarded-last-byte\n", argv[0]);
        return 64;
    }
    const int guarded = strcmp(argv[2], "guarded-last-byte") == 0;
    const long page = sysconf(_SC_PAGESIZE);
    if (page <= 0 || (unsigned long)page > SIZE_MAX / 2) {
        fprintf(stderr, "page-size precondition failed\n"); return 78;
    }
    g_page_size = (size_t)page;
    unsigned char *mapping = mmap(NULL, g_page_size * 2, PROT_READ | PROT_WRITE,
                                  MAP_PRIVATE | MAP_ANON, -1, 0);
    if (mapping == MAP_FAILED) { perror("mmap"); return 78; }
    if (mprotect(mapping + g_page_size, g_page_size, PROT_NONE) != 0) {
        perror("mprotect"); munmap(mapping, g_page_size * 2); return 78;
    }
    struct sigaction action;
    memset(&action, 0, sizeof(action));
    action.sa_sigaction = observe_fault;
    action.sa_flags = SA_SIGINFO;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGBUS, &action, NULL) != 0 || sigaction(SIGSEGV, &action, NULL) != 0) {
        perror("sigaction"); munmap(mapping, g_page_size * 2); return 78;
    }
    g_case = argv[2];
    g_pid = getpid();
    g_guard = (uintptr_t)(mapping + g_page_size);
    g_store_function = (uintptr_t)&opennox_atomicity_store16_v1;
    g_first = mapping + g_page_size - (guarded ? 1 : 2);
    *g_first = 0xAA;
    if (!guarded) g_first[1] = 0xBB;
    printf("{\"schema\":\"opennox-native-word-store-observation-v1\",\"event\":\"before-store\",\"case\":\"%s\",\"pid\":%ld,\"page_bytes\":%zu,\"store_function\":\"0x%016" PRIxPTR "\",\"store_address\":\"0x%016" PRIxPTR "\",\"guard_page\":\"0x%016" PRIxPTR "\",\"accessible_store_bytes\":%d,\"before_first_hex\":\"%02x\",\"store_width_bytes\":2,\"store_value_hex\":\"0002\",\"parent_calls\":0}\n",
        g_case, (long)g_pid, g_page_size, g_store_function, (uintptr_t)g_first,
        g_guard, guarded ? 1 : 2, (unsigned int)*g_first);
    if (fflush(stdout) != 0) { perror("fflush"); return 78; }
    g_armed = 1;
    opennox_atomicity_store16_v1((void *)g_first, UINT16_C(2));
    const unsigned int first_after = *g_first;
    if (guarded) {
        printf("{\"schema\":\"opennox-native-word-store-observation-v1\",\"event\":\"unexpected-store-returned\",\"case\":\"%s\",\"after_first_hex\":\"%02x\",\"parent_calls\":0}\n", g_case, first_after);
        munmap(mapping, g_page_size * 2);
        return 4;
    }
    const unsigned int second_after = g_first[1];
    printf("{\"schema\":\"opennox-native-word-store-observation-v1\",\"event\":\"healthy-store-returned\",\"case\":\"%s\",\"after_first_hex\":\"%02x\",\"after_second_hex\":\"%02x\",\"parent_calls\":0}\n", g_case, first_after, second_after);
    munmap(mapping, g_page_size * 2);
    return first_after == 2 && second_after == 0 ? 0 : 3;
}
