#!/usr/bin/env python3
"""Build/byte-verify a portable original-reference ZIP. No code/CPU execution.

Only reads fixed reference files and creates new artifacts in this directory.
No repository edit, subprocess, cleanup, original emulator, Go, C or game run.
"""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
REPO = Path('/Users/ghost/codex-sandbox/worktrees/opennox-r344-20261020')
RUNS = [('baseline1034', 'original-recording-first-v2', 'root-approved-parent-input-source-seal-v2.json',
         'original-1034-two-FPU-independent-qualified-v4.json', 'first-original-local-recording-exit-v3.json'),
        ('additive4', 'original-recording-additive-nilweapon-v1', 'root-approved-parent-input-source-seal-v3.json',
         'original-additive4-two-FPU-independent-qualified-v4.json', 'additive-original-local-recording-exit-v1.json')]


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':')).encode()+b'\n'


def record(path):
    path = Path(path).resolve()
    hasher, count = hashlib.sha256(), 0
    with path.open('rb') as stream:
        while chunk := stream.read(1 << 20):
            hasher.update(chunk)
            count += len(chunk)
    return dict(path=str(path), bytes=count, sha256=hasher.hexdigest())


def bind(expected):
    actual = record(expected['path'])
    assert (actual['bytes'], actual['sha256']) == (expected['bytes'], expected['sha256'])
    return actual


class Packer:
    def __init__(self):
        self.members, self.sources, self.runs, self.pool = {}, {}, {}, {}

    def add(self, path, member, role, expected=None, memory=None):
        path = Path(path).resolve()
        assert path.is_file() and not path.is_symlink()
        actual = record(path)
        if expected:
            assert (actual['bytes'], actual['sha256']) == (expected['bytes'], expected['sha256']), actual
        self.sources[str(path)] = actual
        if member in self.members:
            row = self.members[member]
            assert (row['bytes'], row['sha256']) == (actual['bytes'], actual['sha256']), member
            assert memory is None or row['uncompressed_memory'] == memory
            if str(path) not in row['canonical_source_paths']:
                row['canonical_source_paths'].append(str(path))
        else:
            row = dict(bytes=actual['bytes'], sha256=actual['sha256'], role=role,
                       canonical_source_paths=[str(path)])
            if memory:
                row['uncompressed_memory'] = memory
            self.members[member] = row
        return member

    def metadata(self, relative, role='provenance'):
        path = PARENT/relative
        return self.add(path, 'provenance/'+relative, role)

    def collect_run(self, label, folder, seal_name, qualification_name, exit_name):
        runout = PARENT/folder
        proof_path = runout/'actual-original-parent-recorder-proof-v2.json'
        proof = json.loads(proof_path.read_text())
        qualification = json.loads((PARENT/qualification_name).read_text())
        seal = json.loads((PARENT/seal_name).read_text())
        exit_report = json.loads((PARENT/exit_name).read_text())
        assert proof['fatal'] is None and qualification['qualified'] is True
        assert qualification['qualifier']['sha256'] == 'c60b5a3850eccc52a4eae2d8e4b430ef424cd823ab9d5a2499497b288ff2006f'
        assert qualification['case_count'] == seal['inputs']['count']
        assert proof['actual_rows'] == 2*qualification['case_count']
        assert qualification['native_fault_atomicity_qualified'] is False
        assert exit_report['returncode'] == 0 and exit_report['forced'] is False
        assert bind(qualification['original_proof']) == record(proof_path)
        assert bind(qualification['input_seal']) == record(PARENT/seal_name)
        for key in ('producer', 'generator', 'services', 'inputs', 'dedicated_manifest'):
            bind(seal[key])
        prefix = 'runs/'+label+'/'
        run = dict(input_case_count=qualification['case_count'],
                   actual_root_calls=proof['actual_entered_originals']['0x004e0b30'],
                   source_HEAD=seal['source_HEAD'], observed_statuses=qualification['observed_statuses'],
                   proof_member=self.add(proof_path, prefix+proof_path.name, 'actual-original-proof'),
                   rows_member=self.add(proof['rows']['path'], prefix+'actual-original-parent-rows-v2.jsonl.gz', 'actual-original-rows', proof['rows']),
                   binding_member=self.add(runout/'input-and-source-binding-v2.json', prefix+'input-and-source-binding-v2.json', 'actual-original-input-binding'),
                   input_seal_member=self.add(PARENT/seal_name, prefix+seal_name, 'preexecution-source-input-seal'),
                   qualification_member=self.add(PARENT/qualification_name, prefix+qualification_name, 'independent-full-certificate-qualification'),
                   exit_member=self.add(PARENT/exit_name, prefix+exit_name, 'actual-original-natural-exit'),
                   stdout_member=self.add(exit_report['stdout']['path'], prefix+'execution.stdout.log', 'actual-original-stdout', exit_report['stdout']),
                   stderr_member=self.add(exit_report['stderr']['path'], prefix+'execution.stderr.log', 'actual-original-stderr', exit_report['stderr']),
                   memory_reference_count=len(proof['memory_snapshots']),
                   authentic_qualification_memory_manifest_sha256=qualification['canonical_memory_member_manifest_sha256'])
        intent = exit_report['intent']
        run['execution_intent_member'] = self.add(intent['path'], prefix+'execution-intent.json', 'actual-original-execution-intent', intent)
        for key in ('producer', 'generator', 'services', 'inputs', 'dedicated_manifest'):
            source = seal[key]
            member = 'sources/'+Path(source['path']).name
            run[key+'_member'] = self.add(source['path'], member, 'frozen-'+key, source)
        self.add(qualification['qualifier']['path'], 'sources/qualify_original_default_damage_parent_4e0b30_v4.py', 'actual-independent-qualifier-v4', qualification['qualifier'])
        for ref in proof['memory_snapshots']:
            member = ref['file']
            assert member == 'memory/'+ref['sha256']+'.bin.gz'
            path = runout/member
            if ref['sha256'] not in self.pool:
                hasher, count = hashlib.sha256(), 0
                with gzip.open(path, 'rb') as stream:
                    while chunk := stream.read(1 << 20):
                        hasher.update(chunk)
                        count += len(chunk)
                assert (count, hasher.hexdigest()) == (ref['bytes'], ref['sha256'])
                self.pool[ref['sha256']] = ref
            else:
                assert self.pool[ref['sha256']] == ref, 'cannot deduplicate differing authentic gzip bytes'
            self.add(path, member, 'full-original-memory-snapshot',
                     dict(bytes=ref['gzip_bytes'], sha256=ref['gzip_sha256']),
                     memory=dict(bytes=ref['bytes'], sha256=ref['sha256']))
        self.runs[label] = run

    def collect_provenance(self):
        selected = [
            'preserved-pre-port-C-definition-4e0b30-v2.txt', 'preserved-pre-port-C-declaration-4e0b30-v2.txt',
            'complete-prior-tracked-source-seal-v1.json', 'root-prephase-source-and-PE-binding-v2.json',
            'root-prephase-source-and-PE-binding-v2.py', 'root-producer-and-input-preexecution-review-v1.json',
            'root-producer-v2-partial-write-revision-review-v1.json', 'root-full-original-row-input-enumeration-observation-v1.json',
            'root-additive-nilweapon-inputs-preexecution-review-v1.json', 'root-generator-in-memory-replay-before-original-v1.json',
            'root-freeze-parent-inputs-before-execution-v1.py', 'run-frozen-original-parent-local-v3.py',
            'run-frozen-original-parent-additive-local-v1.py', 'local-additive-code-verifier-qualified-v1.json',
            'parent-dedicated-14code-3data-exit-v1.json', 'parent-dedicated-14code-3data.stdout-v1.log',
            'parent-dedicated-14code-3data.stderr-v1.log', 'main-unchanged-3373code-713data-exit-v1.json',
            'main-unchanged-3373code-713data.stdout-v1.log', 'main-unchanged-3373code-713data.stderr-v1.log',
            'producer-drafts-v2/producer-source-revision-and-static-lock-v2.json',
            'producer-drafts-v2/independent-partial-write-source-review-v1.json',
            'producer-drafts-v2/root-call-size-metadata-correction-v4.json',
            'producer-drafts-v2/independent-qualifier-v3-source-review-v1.json',
            'producer-drafts-v2/producer-v1-to-v2-observed-partial-write.patch',
            'independent-contract-review-v1/callee-service-field-contract-v1.json',
            'independent-contract-review-v1/static-stack-field-width-certificate-v1.json',
            'independent-contract-review-v1/ORDER-AND-BOUNDARY-HAZARDS-v1.txt',
            'independent-contract-review-v1/independent-input-finalcandidate-1034-review-v1.json',
            'input-freeze-v1/independent-input-freeze-manifest-v1.json', 'input-freeze-v1/independent-input-domain-4e0b30-v1.json',
            'input-freeze-v1/independent-input-schema-4e0b30-v1.json', 'input-freeze-v1/input-generation-receipt-v1.json',
            'input-freeze-v1/input-static-validation-v1.json', 'input-freeze-v1/stimulus-static-instruction-check-v1.json',
            'input-freeze-v1/INPUT-DOMAIN-AND-FREEZE-v1.txt',
            'nilweapon-shield-additive-inputs-v1/additive-preexecution-proposal-v1.json',
            'nilweapon-shield-additive-inputs-v1/additive-input-generation-receipt-v1.json',
            'original-1034-independent-qualification-v4.stdout.log', 'original-1034-independent-qualification-v4.stderr.log',
            'original-additive4-independent-qualification-v4.stdout.log', 'original-additive4-independent-qualification-v4.stderr.log',
            'native-word-store-independent-observation-review-v1/POSTFAULT-COMPARISON-POLICY-ADDENDUM-v1.txt',
            'native-word-store-independent-observation-review-v1/independent-native-word-store-observation-review-v1.json',
            'native-word-store-independent-observation-review-v1/independent-word-store-review-manifest-v1.json',
            'native-word-store-preexec-v1.py', 'run-native-word-store-local-v1.py',
        ]
        for relative in selected:
            self.metadata(relative)
        for folder in ('native-word-store-control-local-v1', 'native-word-store-fault-control-drafts-v1'):
            for path in sorted((PARENT/folder).iterdir()):
                assert path.is_file(), path
                self.add(path, 'physical-observation/'+folder+'/'+path.name, 'standalone-native-physical-observation')
        older = PARENT.parent/'damage-predicates-4e1400-native-entry-port/raw-parent-4e0b30-readonly-plan-v1'
        for name in ('READ-ONLY-STAGED-PLAN-v1.txt', 'static-original-and-current-source-facts-v1.json'):
            self.add(older/name, 'provenance/prior-static-parent-plan/'+name, 'prior-static-contract-only')
        main = REPO/'toolchain/oracle/game-exe-functions.json'
        self.add(main, 'provenance/unchanged-main-game-exe-functions.json', 'unchanged-3373code-713data-manifest')
        self.add(REPO/'toolchain/oracle/nox-2023-1003-01.json', 'provenance/original-oracle-identity.json', 'original-oracle-identity')
        # Explicit bounded independently reviewed inventory, not a recursive old
        # phase copy. Large original failure rows remain references in ART.
        inventory_path = HERE/'independent-inventory-v1.json'
        inventory = json.loads(inventory_path.read_text())
        assert inventory['recommended_files_count'] == len(inventory['recommended_files']) == 93
        for entry in inventory['recommended_files']:
            path = Path(entry['path'])
            if str(path.resolve()) not in self.sources:
                assert entry['bytes'] < 2 << 20
                relative = entry.get('relative_to_parent')
                member = 'provenance/'+relative if relative else 'provenance/source-anchors/'+path.name
                self.add(path, member, entry['role'], entry)
        self.add(inventory_path, 'provenance/independent-bundle-inventory-v1.json', 'independent-byteverified-input-inventory')
        self.add(PARENT/'producer-drafts-v1/original_default_damage_parent_4e0b30_v1.py',
                 'provenance/historical-source/original_default_damage_parent_4e0b30_v1.py', 'preserved-prior-producer-source-only')
        for path in (Path(__file__), HERE/'read_reference_bundle_v1.py', HERE/'REFERENCE-SCOPE-v1.txt'):
            self.add(path, 'tools/'+path.name, 'portable-bundle-tool-or-scope')

    def make(self, output):
        assert not output.exists()
        for run in RUNS:
            self.collect_run(*run)
        self.collect_provenance()
        qualities = [json.loads((PARENT/run[3]).read_text()) for run in RUNS]
        parent_boundaries = set(json.loads((PARENT/RUNS[0][1]/'actual-original-parent-recorder-proof-v2.json').read_text())[
            'original_completed_instruction_coverage_union'])
        for q in qualities:
            parent_boundaries |= set(q['completed_instruction_counts'])
        parent_static = json.loads((PARENT/RUNS[0][1]/'actual-original-parent-recorder-proof-v2.json').read_text())['original_static_instruction_boundaries']['parent']
        assert len(parent_static) == 592 and all(i['pc'] in parent_boundaries for i in parent_static)
        failure_refs = []
        for relative in ('original-recording-first-v1/actual-original-parent-recorder-proof-v1.json',
                         'original-1034-two-FPU-independent-qualified-v3.json',
                         'original-additive4-two-FPU-independent-qualified-v3.json',
                         'first-original-failure-partial-write-forensic-v1.json',
                         'root-wrapper-v2-launch-failure-retained-v1.json'):
            failure_refs.append(dict(**record(PARENT/relative), included_in_bundle=str((PARENT/relative).resolve()) in self.sources,
                                     preserved_in_ART=True))
        index = dict(schema='opennox-default-damage-parent-portable-reference-bundle-v1',
                     index_member='bundle-index-v1.json', members=dict(sorted(self.members.items())), runs=self.runs,
                     scope=dict(original_parent_body_bytes=1783, original_padding_bytes=9,
                                actual_original_child_bytes=[112, 34], actual_original_converter_bytes=17,
                                frozen_input_cases=sum(r['input_case_count'] for r in self.runs.values()),
                                actual_original_root_calls=sum(r['actual_root_calls'] for r in self.runs.values()),
                                parent_completed_boundaries=592, parent_static_boundaries=592,
                                actual_original_reference_certificates_qualified=True,
                                parent_all_static_instruction_boundaries_completed=True,
                                original_external_helper_bodies_executed=False, native_parent_engine_qualified=False,
                                native_fault_postmemory_equivalence_qualified=False, native_fault_atomicity_qualified=False,
                                natural_campaign_or_product_entry_qualified=False, physical_speaker_qualified=False,
                                whole_pointer_port_100_percent=False, CI_used=False),
                     shared_memory=dict(original_run_references=sum(r['memory_reference_count'] for r in self.runs.values()),
                                        unique_members=len(self.pool), unique_gzip_bytes=sum(r['gzip_bytes'] for r in self.pool.values()),
                                        duplicate_references_removed=sum(r['memory_reference_count'] for r in self.runs.values())-len(self.pool)),
                     portability=dict(authentic_record_bytes_unchanged=True, old_absolute_paths_preserved_as_provenance=True,
                                      resolve_old_paths_through='members[*].canonical_source_paths',
                                      snapshot_ref_file_is_shared_pool_member=True, original_GAME_EXE_not_copied=True,
                                      replay_requires_external_original_EXE_SHA256='0040e2c0683b4d73a5fb976e400d5087dca680df2b195c9e27f8edbda2d4974a',
                                      original_producer_or_qualifier_not_silently_relocated=True),
                     physical_observation=dict(Unicorn_partial_word_prefix_after_hex='02', native_ARM64_STRH_prefix_after_hex='aa',
                                               standalone_native_parent_calls=0, observations_are_separate=True,
                                               Windows_x86_physical_atomicity_qualified=False),
                     historical_failures_preserved_in_ART=failure_refs)
        index_data = canonical(index)
        with zipfile.ZipFile(output, 'x', allowZip64=True) as archive:
            archive.writestr('bundle-index-v1.json', index_data, compress_type=zipfile.ZIP_DEFLATED)
            for name, row in sorted(self.members.items()):
                source = Path(row['canonical_source_paths'][0])
                info = zipfile.ZipInfo(name, date_time=(2026, 11, 7, 0, 0, 0))
                info.compress_type = zipfile.ZIP_STORED if name.endswith(('.gz', '.zip')) else zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                hasher, count = hashlib.sha256(), 0
                with source.open('rb') as data, archive.open(info, 'w', force_zip64=True) as destination:
                    while chunk := data.read(1 << 20):
                        destination.write(chunk)
                        hasher.update(chunk)
                        count += len(chunk)
                assert (count, hasher.hexdigest()) == (row['bytes'], row['sha256']), name
        with zipfile.ZipFile(output) as archive:
            assert len(archive.namelist()) == len(set(archive.namelist())) == len(self.members)+1
            assert archive.read('bundle-index-v1.json') == index_data
            for name, expected in self.members.items():
                hasher, count = hashlib.sha256(), 0
                with archive.open(name) as stream:
                    while chunk := stream.read(1 << 20):
                        hasher.update(chunk)
                        count += len(chunk)
                assert (count, hasher.hexdigest()) == (expected['bytes'], expected['sha256']), name
        for path, expected in self.sources.items():
            assert record(path) == expected, 'canonical source changed during packaging'
        install = HERE/'installation-files'
        assert not install.exists()
        td = install/'src/legacy/testdata/default_damage_parent_4e0b30'
        td.mkdir(parents=True)
        assignments = [(HERE/'read_reference_bundle_v1.py', td/'read_reference_bundle_v1.py'),
                       (HERE/'REFERENCE-SCOPE-v1.txt', td/'REFERENCE-SCOPE-v1.txt'),
                       (PARENT/'producer-drafts-v2/original_default_damage_parent_4e0b30_v2.py', td/'original_default_damage_parent_4e0b30_v2.py'),
                       (PARENT/'producer-drafts-v2/qualify_original_default_damage_parent_4e0b30_v4.py', td/'qualify_original_default_damage_parent_4e0b30_v4.py'),
                       (PARENT/'input-freeze-v1/generate-independent-inputs-4e0b30-v1.py', td/'generate-independent-inputs-4e0b30-v1.py'),
                       (PARENT/'nilweapon-shield-additive-inputs-v1/generate-additive-nilweapon-shield-inputs-v1.py', td/'generate-additive-nilweapon-shield-inputs-v1.py'),
                       (PARENT/'game-exe-default-damage-parent-4e0b30-v2.json', install/'toolchain/oracle/game-exe-default-damage-parent-4e0b30.json')]
        installation = [dict(source=str(output), repository_target='src/legacy/testdata/default_damage_parent_4e0b30/'+output.name,
                             **{k: v for k, v in record(output).items() if k != 'path'})]
        for source, destination in assignments:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
            original, copied = record(source), record(destination)
            assert (original['bytes'], original['sha256']) == (copied['bytes'], copied['sha256'])
            installation.append(dict(source=str(destination), repository_target=str(destination.relative_to(install)),
                                     bytes=copied['bytes'], sha256=copied['sha256'], canonical_original=str(source)))
        installation_manifest = dict(schema='opennox-default-damage-parent-reference-installation-draft-v1',
                                     repository_written=False, root_installs_only=True, files=installation,
                                     main_manifest_replaced=False, existing_goldens_or_inputs_changed=False,
                                     new_C_or_Go_production_engine_included=False,
                                     portable_bundle_may_be_read_without_rewriting_authentic_paths=True)
        install_path = HERE/'reference-installation-list-v1.json'
        install_path.write_bytes(canonical(installation_manifest))
        receipt = dict(schema='opennox-default-damage-parent-reference-bundle-byteverified-v1', bundle=record(output),
                       index_bytes=len(index_data), index_sha256=hashlib.sha256(index_data).hexdigest(),
                       member_count=len(self.members), canonical_source_path_count=len(self.sources),
                       source_files_byte_verified_after_archive=True, every_archived_member_byte_verified=True,
                       every_full_memory_plain_SHA_verified_before_archive=True, shared_memory=index['shared_memory'],
                       scope=index['scope'], installation_list=record(install_path), packer=record(__file__),
                       portable_reader=record(HERE/'read_reference_bundle_v1.py'),
                       repository_changes=False, original_or_Go_or_C_or_game_execution=False,
                       originals_failures_and_canonical_snapshots_deleted=False)
        path = HERE/'reference-bundle-byteverification-and-source-manifest-v1.json'
        assert not path.exists()
        path.write_bytes(canonical(receipt))
        return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-and-byteverify', action='store_true', required=True)
    args = parser.parse_args()
    result = Packer().make(HERE/'default-damage-parent-4e0b30-reference-v1.zip')
    print(json.dumps(dict(bundle=result['bundle'], members=result['member_count'], shared_memory=result['shared_memory'],
                          scope=result['scope'], installation_list=result['installation_list'])))


if __name__ == '__main__':
    main()
