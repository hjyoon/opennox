"""Static additive preparation only; no compiler, native call or oracle run."""
from pathlib import Path
import hashlib, json, re, struct, subprocess

R = Path('/Users/ghost/codex-sandbox/worktrees/opennox-r344-20261020')
D = Path(__file__).resolve().parent
OLD = D.parent/'damage-predicates-4e1400-native-entry-port'
EXE = Path('/Users/ghost/codex-sandbox/nox-pjt/Nox/GAME.EXE')
sha = lambda b: hashlib.sha256(b).hexdigest()
def identity(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=sha(b))
def write(name, data):
    p = D/name
    assert not p.exists(), str(p)
    p.write_bytes(data)
    return identity(p)
def write_json(name, data):
    return write(name, (json.dumps(data, indent=2)+'\n').encode())

head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=R, text=True).strip()
assert head == 'a9515bb6366c7818cb0e63d81cd43c2db2998a28'
assert subprocess.check_output(['git','status','--porcelain'], cwd=R) == b''
priorpath = OLD/'local-full-five-damage-v1/full-five-damage-current-source-input-seal-v1.json'
prior = json.loads(priorpath.read_bytes())
assert len(prior['source93']) == 93
for path, expected in prior['source93'].items():
    b = (R/path).read_bytes()
    assert dict(bytes=len(b), sha256=sha(b)) == expected, path
mutable = ['src/legacy/GAME3_2.c','src/legacy/GAME3_2.h','src/legacy/GAME3_3.c']
protected = {p:v for p,v in prior['source93'].items() if p not in mutable}
assert len(protected) == 91
source = (R/'src/legacy/GAME3_2.c').read_bytes()
sig = b'int nox_xxx_damageDefaultProc_4E0B30(int a1, int a2, int a3, int a4, int a5) '
start = source.index(sig)
brace = start+len(sig)
assert source[brace:brace+1] == b'{'
end = source.index(b'\n}\n', brace)+3
definition = source[start:end]
body = source[brace:end]
assert len(body) == 8764 and sha(body) == '94b4f7cb0ac71a8adbc80319dd114cf9ece75ee9742c9339178f00380b4217be'
oldsource = write('preserved-pre-port-C-definition-4e0b30-v2.txt', definition)
header = (R/'src/legacy/GAME3_2.h').read_bytes()
decl = sig.rstrip()+b';'
assert header.splitlines().count(decl) == 1
declfile = write('preserved-pre-port-C-declaration-4e0b30-v2.txt', decl+b'\n')

raw = EXE.read_bytes()
assert len(raw) == 1929216
assert sha(raw) == '0040e2c0683b4d73a5fb976e400d5087dca680df2b195c9e27f8edbda2d4974a'
pe = struct.unpack_from('<I', raw, 60)[0]
opt = pe+24
base = struct.unpack_from('<I', raw, opt+28)[0]
tab = opt+struct.unpack_from('<H',raw,pe+20)[0]
sections = []
for i in range(struct.unpack_from('<H',raw,pe+6)[0]):
    k = tab+40*i
    virtual, rva, length, off = struct.unpack_from('<IIII',raw,k+8)
    flags = struct.unpack_from('<I',raw,k+36)[0]
    sections.append((base+rva, length, off, bool(flags & 0x20000000)))
def read(address, size):
    for va,n,off,executable in sections:
        if va <= address and address+size <= va+n:
            return raw[off+address-va:off+address-va+size], executable
    raise AssertionError(hex(address))
def rec(name, addr, size, purpose, data=False):
    b,exe = read(addr,size)
    r = dict(name=name,address=f'0x{addr:08X}',size=size,sha256=sha(b),purpose=purpose)
    if data:
        if exe: r['executable_section'] = True
    else: assert exe
    return r
mainpath = R/'toolchain/oracle/game-exe-functions.json'
main = json.loads(mainpath.read_bytes())
assert len(main['functions']) == 3373 and len(main['data']) == 713
functions = [rec('raw_DefaultDamage_complete_body_4E0B30',0x4e0b30,1783,
    'Complete unchanged parent through final RET; external-service execution boundaries must be declared separately; no natural-gameplay admission claim.')]
for addr,name,n,digest in [
    (0x4e1400,'raw_attack_predicate_4E1400',112,'0ac2ef45c5c13d020b99663c9fcac15321cdf3b825cabb3b44c746aae5a4fb73'),
    (0x4e1470,'raw_friendly_predicate_4E1470',34,'fa632520ae8b970b679dd6c5b8bd947f81f4b41d65295f6d3a26edbcb975b92e'),
    (0x419a70,'signed_float_to_DWORD_419A70',17,'10e536e2a987ea0fe14c91f007b2d5361cd87d4f0ca4cf5385fc82e53913d186')]:
    candidates = [r for r in main['functions'] if int(r['address'],16)==addr and r['size']==n]
    # Historical aliases remain untouched; bind the exact binary tuple.
    assert candidates and {r['sha256'] for r in candidates} == {digest}
    row = rec(name,addr,n,'Unchanged original real helper body; service stubs must not replace this body in the new parent producer.')
    assert row['sha256']==candidates[0]['sha256']
    if digest: assert row['sha256']==digest
    functions.append(row)
incoming = [0x4e14e5,0x4e154a,0x4e2098,0x4e249d,0x4e24c9,0x4e250b,0x4e254d,0x4e258f,0x4e28c7]
for site in incoming:
    b,_ = read(site,5)
    assert b[0]==0xe8 and site+5+struct.unpack_from('<i',b,1)[0]==0x4e0b30
    functions.append(rec(f'raw_DefaultDamage_incoming_CALL_{site:08X}',site,5,
        'Original incoming CALL instruction only. Does not qualify the enclosing caller, its runtime admission or its native pointer ABI.'))
b,_ = read(0x4e2d3a,10)
assert struct.unpack_from('<I',b,6)[0]==0x4e0b30
functions.append(rec('raw_DefaultDamage_initializer_store_4E2D3A',0x4e2d3a,10,
    'Original complete MOV instruction storing the parent callback at the object-type default slot; no execution credit.'))
functions.sort(key=lambda r:int(r['address'],16))
data = [
    rec('raw_DefaultDamage_trailing_NOP9_4E1227',0x4e1227,9,'Trailing NOP padding outside the complete 1783-byte parent body.',True),
    rec('raw_DefaultDamage_name_callback_record_5CA058',0x5ca058,8,'Exact eight-byte name-pointer/callback-pointer record; not a 12-byte parser record.',True),
    rec('raw_DefaultDamage_name_aligned_5CA0D0',0x5ca0d0,16,'DefaultDamage NUL-terminated name and two unchanged padding bytes.',True)]
assert read(0x4e1227,9)[0] == b'\x90'*9
assert struct.unpack('<II',read(0x5ca058,8)[0]) == (0x5ca0d0,0x4e0b30)
assert read(0x5ca0d0,16)[0] == b'DefaultDamage\0\0\0'
assert functions[1]['address'] == '0x004E0B30'
assert next(r for r in functions if r['address']=='0x004E0B30')['sha256']=='4cf4af9b19b58d3912660df35a7b47010c363e5f595aa4ac1e74c3adae541fe1'
manifest = {k:main[k] for k in ['schema','oracle_id','path','file_sha256','format','image_base']}
manifest.update(allow_overlapping_ranges=False,functions=functions,data=data)
manifest_id = write_json('game-exe-default-damage-parent-4e0b30-v2.json',manifest)
assert len(functions)==14 and len(data)==3
report = dict(schema='opennox-parent-prephase-source-and-PE-binding-v2',phase='static-only-additive-preparation',
    source_HEAD=head,prior_qualified_code='4303b76071b0b20d0bfa9dc67c70ad58516c77ea',
    prior_phase_seal=identity(priorpath),all_prior_93_exact=True,
    immutable_prior_inputs91=protected,reviewed_future_mutable_C_and_header=[identity(R/p) for p in mutable],
    individual_source_policy=identity(OLD/'raw-parent-4e0b30-readonly-plan-v1/individual-source-preservation-policy-v1.json'),
    old_C_definition=oldsource,old_C_brace_through_closing_newline=dict(bytes=len(body),sha256=sha(body)),
    old_C_declaration=declfile,original_EXE=identity(EXE),main_manifest=identity(mainpath),
    main_manifest_records=dict(functions=3373,data=713),main_manifest_unchanged=True,
    additive_manifest=manifest_id,additive_records=dict(functions=14,data=3),
    original_execution=False,native_execution=False,callee_body_credit=False,input_freeze=False,
    repository_changed=False,network_or_CI=False,overall100=False)
receipt = write_json('root-prephase-source-and-PE-binding-v2.json',report)
assert subprocess.check_output(['git','status','--porcelain'], cwd=R)==b''
print(json.dumps(dict(receipt=receipt,definition=oldsource,manifest=manifest_id,prior93_exact=True,protected91=True)))
