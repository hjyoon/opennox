"""Root-reviewed inputs and sources are immutable before any parent oracle run."""
from pathlib import Path
import argparse, ast, datetime, gzip, hashlib, json, subprocess, sys

D=Path(__file__).resolve().parent
R=Path('/Users/ghost/codex-sandbox/worktrees/opennox-r344-20261020')
EXE=Path('/Users/ghost/codex-sandbox/nox-pjt/Nox/GAME.EXE')
sha=lambda b:hashlib.sha256(b).hexdigest()
def identity(p):
    b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=sha(b))
def write(name,x):
    p=D/name
    with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
    return identity(p)
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--independent-input-review',type=Path,required=True)
parser.add_argument('--producer-sha256',required=True)
parser.add_argument('--generator-sha256',required=True)
args=parser.parse_args()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='a9515bb6366c7818cb0e63d81cd43c2db2998a28'
assert subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
prior=D/'complete-prior-tracked-source-seal-v1.json'
complete=json.loads(prior.read_bytes())
assert complete['tracked_count']==8681
for path,want in complete['tracked_files'].items():
    got=identity(R/path)
    assert dict(bytes=got['bytes'],sha256=got['sha256'])==want,path
binding=json.loads((D/'root-prephase-source-and-PE-binding-v2.json').read_bytes())
for expected in [binding['old_C_definition'],binding['old_C_declaration'],binding['original_EXE'],binding['main_manifest'],binding['additive_manifest']]:
    assert identity(Path(expected['path']))==expected
for name in ['raw_default_damage_native_4e0b30.go','raw_default_damage_export_4e0b30.go']:
    assert not (R/'src/legacy'/name).exists()
source=(R/'src/legacy/GAME3_2.c').read_bytes()
assert source.count(Path(binding['old_C_definition']['path']).read_bytes())==1
producer=D/'producer-drafts-v1/original_default_damage_parent_4e0b30_v1.py'
generator=D/'input-freeze-v1/generate-independent-inputs-4e0b30-v1.py'
assert identity(producer)['sha256']==args.producer_sha256
assert identity(generator)['sha256']==args.generator_sha256
for p in [producer,generator]:ast.parse(p.read_text(),filename=str(p))
review=json.loads(args.independent_input_review.read_bytes())
assert review, 'independent review required; root must inspect the full receipt before running this tool'
zipped=D/'input-freeze-v1/chosen-independent-inputs-4e0b30-v1.json.gz'
plain=D/'input-freeze-v1/chosen-independent-inputs-4e0b30-v1.json'
packed=zipped.read_bytes();data=gzip.decompress(packed)
assert plain.read_bytes()==data
payload=json.loads(data)
assert payload['schema']=='opennox-default-damage-parent-independent-inputs-v1'
assert len(payload['cases'])==payload['case_count']
assert payload['inputs_only'] and not payload['execution_performed']
assert len({c['name'] for c in payload['cases']})==len(payload['cases'])
replay=subprocess.run([sys.executable,str(generator),'--check-only'],cwd=D,capture_output=True,check=False)
write('root-generator-in-memory-replay-before-original-v1.json',dict(
    command=[sys.executable,str(generator),'--check-only'],returncode=replay.returncode,
    stdout=replay.stdout.decode(),stderr=replay.stderr.decode(),source=identity(generator),
    original_calls=0,native_calls=0))
assert replay.returncode==0
services=D/'producer-drafts-v1/service-boundaries-4e0b30-v1.json'
serviceobj=json.loads(services.read_bytes())
assert serviceobj['counts']==dict(parent_call_sites=53,direct_call_sites=50,direct_unique_targets=28,
    actual_child_sites=3,actual_converter_sites=8,external_direct_sites=39,
    external_direct_unique_targets=25,indirect_sites=3)
assert sum(r['size'] for r in serviceobj['actual_original_ranges'])==1946
rootreview=write('root-producer-and-input-preexecution-review-v1.json',dict(
    schema='opennox-raw-parent-root-preexecution-review-v1',producer=identity(producer),generator=identity(generator),
    independent_input_review=identity(args.independent_input_review),
    findings_addressed_before_freeze=[
        'Exact tuple binding preserves all historical manifest aliases.',
        'Original children112/34 and converter17 execute as real complete bodies.',
        'Other25direct/3indirect targets are explicit input boundaries with zero helper-body credit.',
        'PreDamage records five outgoing words; separately certified fifth unused by original callee.',
        'Owner cache, exact-one field-guide, signed sound count and unmasked VampFX amount retained.',
        'Caller source/protection and damage words, whole memory, registers and FPU are retained without masking.',
        'After-read stimuli occur after completion; never replace original loaded values.',
        'Initial NoUpdate, partial late fields and self-ManaBomb zero inputs added before execution.',
        'Physical fault prefixes and all unused stimuli remain explicit observations.',
        'Recorder hook/resource disposal and actual entered/completed counts reviewed.'
    ],root_reviewed_before_execution=True,original_calls=0,native_parent_calls=0,engine_implementation=False,
    native_expected_output_computation=False,CI=False,overall100=False))
seal=dict(schema='opennox-default-damage-parent-input-freeze-v1',
    frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    freeze_tool=identity(Path(__file__)),python=sys.executable,
    root_reviewed_before_execution=True,native_engine_exists=False,
    source_HEAD=complete['source_HEAD'],producer=identity(producer),generator=identity(generator),
    services=identity(services),original_EXE=identity(EXE),
    unchanged_main_manifest=binding['main_manifest'],dedicated_manifest=binding['additive_manifest'],
    inputs={**identity(zipped), 'count':len(payload['cases']),
        'uncompressed_bytes':len(data),'uncompressed_sha256':sha(data)},
    all_prior_8681_tracked_source_seal=identity(prior),prior93_exact=True,protected_prior91=True,
    independent_input_review=identity(args.independent_input_review),root_preexecution_review=rootreview,
    actual_local_code_verifier_qualification=identity(D/'local-additive-code-verifier-qualified-v1.json'),
    no_original_parent_execution_yet=True,no_native_parent_execution_yet=True,CI=False,overall100=False)
receipt=write('root-approved-parent-input-source-seal-v1.json',seal)
# Canonical compressed inputs plus the unchanged generator retain every byte.
# Preserve all failure artifacts. Remove only this owned duplicate raw JSON.
before=identity(plain)
assert gzip.decompress(zipped.read_bytes())==plain.read_bytes()
plain.unlink()
write('owned-raw-input-duplicate-byteverified-cleanup-v1.json',dict(
    removed=before,canonical=identity(zipped),uncompressed_bytes=len(data),uncompressed_sha256=sha(data),
    all_decompressed_bytes_equal_before_removal=True,root_input_seal=receipt,
    original_inputs_retained_as_canonical_gzip=True,generator_retained=identity(generator),
    original_assets_Save_goldens_failures_untouched=True))
assert subprocess.check_output(['git','status','--porcelain'],cwd=R)==b''
print(json.dumps(receipt))
